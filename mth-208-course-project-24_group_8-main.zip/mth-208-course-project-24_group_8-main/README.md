# Project Repository
Group Members:
- 241080097	Shreyasi Mondal	
- 210911	SAMARTH KUMAR	
- 241080075	Krati Jain	
- 210703	PARMAR SOHAM MULJIBHAI

# Are Top-10 Ranked Test Cricketers Really That Good?
Our project aims to answer this question! We want to see if a player's statistcs can be inflated, and if so how?

This repository contains **ALL** the code, analysis, document and presentation for our group project.
  

