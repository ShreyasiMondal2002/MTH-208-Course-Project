# Shiny App

This repository contains the Shiny app code. We have one UI.R file and multiple Server.R files. This is to keep the code base organised. Each server is for a different pane of the UI. 

## To Run App:
Simply clone the complete git repository and navigate to the current folder. Open ui.R and set this directory to the current working directory. Then press run app!

## Libraries Required to Run the App:
- bslib
- tidyverse
- shiny
- ggplot2
- dplyr
