# Data Scrapping and Formatting

## General
This repository contains the .RData files and the codes required to generate them. There are four main .RData files that have been created after scrapping and formatting the data:
  1. Allrounders_ball.RData
  2. Allrounders_bat.RData
  3. Ballers.RData
  4. Batters.RData

The data contained within these files is used for analysis by the functions in the analysis repository. The three folders all contain code to generate the corresponding .Rdata files. 
They also contain .RData files that have been formed when we needed to combine data frames. In each of the three folders, there are Python scripts and R scripts. 

The code is structured in the following way: 
R ---(Calls Python)---> Python ----> Simulates Web browser and scraped table --(Sends Data to R)--> R Processes Data 

## Notes on Reproducing the code
- The Python environment used for the code is present in the .yml, with Python 3.13. Please create a new environment(preferably using conda) with the exact same specifications.

- We have simulated a web browser using Selenium on a Windows environment. This browser used Google Chrome, along with the AdBlock extension block origin. You may need to install the corresponding webrivers on your machine. 

- In addition, certain paths to the location of the extension are required; these need to be changed depending on the machine being used. The code has been commented on, so finding the location to change is straightforward. Please note that changes must be made to all Python scripts. 

- For Unix-based OSs, the code may require modifications. 
